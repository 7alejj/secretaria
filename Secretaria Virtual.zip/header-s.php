<?php 
require_once 'conexion.php';
?>

<head>
<meta charset="utf-8">
    <link rel="stylesheet" href="css/estindex.css">
<meta name="viewport" content="width=device-width, initial-scale=0.3,  maximum-scale=1">
    <script type="text/javascript" src="css/Script.js"></script>
</head>
    
<header>
    <div id="div1">
        <img src="img/logo1.png" >
        <a href="index.html" >Secretaria<br>Virtual</a></div>
</header>
<nav  id="nav">
    <ul> 
    <li></li>    
    <li class="li"  id="a-s1"><a class="a-s6" href="help1.php">Ayuda</a></li>
    <li class="li" id="a-s2" ><a class="a-s6" href="index.php" >Inicio</a></li>  
    <li class="li" id="a-s3" ><a class="a-s6" href="registrarme.php" >Registrarme</a></li> 
    <li></li>
    </ul></nav>
