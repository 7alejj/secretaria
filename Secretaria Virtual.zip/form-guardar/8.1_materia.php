<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="8.2_opg.php">
        <table>
            <tr>
            <td>DNI Profesor</td>
            <td><input name="dni_profesor"> </td>
            </tr><tr>
            <td>Materia Nombre</td>
            <td><input name="materia_nombre"></td>
            </tr><tr>
            <td>Materia Depto</td>
            <td><input name="materia_depto"> </td>
            </tr><tr>
            <td>Materia Contenidos</td>
            <td><input name="materia_contenidos"></td>
            </tr><tr>
            <td>Materia Modulos</td>
            <td><input name="materia_modulos"> </td>
            </tr><tr>
            <td>Materias curso</td>
            <td><input name="materias_curso"></td>
            </tr><tr>
            <td>Materia Especialidad</td>
            <td><input name="materia_especialidad"> </td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>