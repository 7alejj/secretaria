<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="3.2_opg.php">
        <table>
        <tr><td>Cupo</td>
            <td> <input name="cupo" REQUIERED </td>
            </tr>
            <tr>
            <td>ID materia</td>
            <td><input name="id_materia"> </td>
            </tr><tr>
            <td>Curso Div</td>
            <td><input name="curso_div"></td>
            </tr><tr>
            <td>Grupo</td>
            <td><input name="grupo"> </td>
            </tr><tr>
            <td>DNI Profesor</td>
            <td><input name="dni_profedor"></td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>