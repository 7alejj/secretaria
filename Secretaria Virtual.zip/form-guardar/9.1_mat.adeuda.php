<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="9.2_opg.php">
        <table>
            <tr>
            <td>ID calificaciónr</td>
            <td><input name="id_calificacion"> </td>
            </tr><tr>
            <td>Fecha del Examen</td>
            <td><input name="fecha_examen"></td>
            </tr><tr>
            <td>Libro Acta</td>
            <td><input name="libro_acta"> </td>
            </tr><tr>
            <td>Folio Acta</td>
            <td><input name="folio_acta"></td>
            </tr><tr>
            <td>Nota de Examen</td>
            <td><input name="nota_examen"> </td>
            </tr><tr>
            <td>Condicion</td>
            <td><input name="condicion"></td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>