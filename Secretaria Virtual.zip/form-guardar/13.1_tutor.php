<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="GET" name="form_alum" action="13.2_opg.php">
        <table>
            <tr>
            <td>nombre</td>
            <td><input name="nombre"></td>
            </tr>
            <tr>
            <td>Apellido</td>
            <td><input name="apellido"> </td>
            </tr>
            <tr>
            <td>dni del alumno</td>
            <td><input name="alumno"></td>
            </tr>
            <tr>
            <td>parentezco</td>
            <td><input name="parentezco"> </td>
            </tr>
            <tr>
            <td>dni del tutor</td>
            <td><input name="dni_tutor"></td>
            </tr><tr>
            <td>telefono</td>
            <td><input name="telefono"> </td>
            </tr>
            <td>Celular</td>
            <td><input name="celular"> </td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>