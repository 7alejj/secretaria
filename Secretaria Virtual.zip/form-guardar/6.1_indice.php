<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="6.2_opg.php">
        <table>
            <tr>
            <td>Año ingreso</td>
            <td><input name="anio_ingreso"> </td>
            </tr><tr>
            <td>Legajo</td>
            <td><input name="Legajo"></td>
            </tr><tr>
            <td>Libro Matiz</td>
            <td><input name="libro_matiz"> </td>
            </tr><tr>
            <td>Folio Matiz</td>
            <td><input name="folio_matiz"></td>
            </tr><tr>
            <td>ID Alumno</td>
            <td><input name="id_alumno"> </td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>