<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="11.2_opg.php">
        <table>
            <tr>
            <td>Cuil</td>
            <td><input name="cuil"> </td>
            </tr><tr>
            <td>Apellido</td>
            <td><input name="apellido"></td>
            </tr><tr>
            <td>Nombre</td>
            <td><input name="nombre"> </td>
            </tr><tr>
            <td>Fecha Nacimiento</td>
            <td><input name="f_nacimiento"></td>
            </tr><tr>
            <td>Género</td>
            <td><input name="sexo"> </td>
            </tr><tr>
            <td>Numero de la Calle</td>
            <td><input name="n_calle"></td>
            </tr><tr>
            <td>Localidad</td>
            <td><input name="localidad"> </td>
            </tr><tr>
            <td>Telefono</td>
            <td><input name="telefono"></td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>