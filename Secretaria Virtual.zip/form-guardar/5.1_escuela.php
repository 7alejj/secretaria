<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="5.2_opg.php">
        <table>
        <tr><td>Escuela nombre</td>
            <td> <input name="escuela_nombre" REQUIERED </td>
            </tr>
            <tr>
            <td>esuela cue (No se que quisieron poner acá)</td>
            <td><input name="esuela_cue"> </td>
            </tr><tr>
            <td>Escuela direccion</td>
            <td><input name="escuela_direccion"></td>
            </tr><tr>
            <td>Escuela Sigla</td>
            <td><input name="escuela_sigla"> </td>
            </tr><tr>
            <td>Escuela Tipo</td>
            <td><input name="escuela_tipo"></td>
            </tr><tr>
            <td>Escuela Num</td>
            <td><input name="escuela_nro"> </td>
            </tr><tr>
            <td>Escuela telefono</td>
            <td><input name="escuela_telefono"></td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>