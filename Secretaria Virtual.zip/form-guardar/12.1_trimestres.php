<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="11.2_opg.php">
        <table>
            <tr>
            <td>ID Profesor</td>
            <td><input name="id_profesor"> </td>
            </tr><tr>
            <td>ID alumno</td>
            <td><input name="id_alumno"></td>
            </tr><tr>
            <td>1er Trimestre</td>
            <td><input name="1trimestre"> </td>
            </tr><tr>
            <td>2do Trimestre</td>
            <td><input name="2trimestre"></td>
            </tr><tr>
            <td>3er Trimestre</td>
            <td><input name="3trimestre"> </td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>