<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="2.2_opg.php">
        <table>
        <tr><td>ID Alumno</td>
            <td> <input name="id_alumno" REQUIERED </td>
            </tr>
            <tr>
            <td>ID materia</td>
            <td><input name="id_materia"> </td>
            </tr><tr>
            <td>ID trimestre</td>
            <td><input name="id_trimestre"> </td>
            </tr><tr>
            <td>Cliclo Lectivo</td>
            <td><input name="ciclo_lectivo"></td>
            </tr><tr>
            <td>Promedio Anual</td>
            <td><input name="promedio_anual"></td>
            </tr><tr>
            <td>Calificación Definitiva</td>
            <td><input name="calificacion_definitiva"></td>
            </tr><tr>
            <td>Rinde por Inasistencia</td>
            <td><input name="rinde_x_inasistencia"></td>
            </tr><tr>
            <td>Curso Div</td>
            <td><input name="curso_div"></td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>