<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    </head>
<body>
    <center>
    <form method="post" name="form_alum" action="4.2_opg.php">
        <table>
        <tr><td>Especialidad</td>
            <td> <input name="especialidad" REQUIERED </td>
            </tr>
            <tr>
            <td>Aula</td>
            <td><input name="aula"> </td>
            </tr><tr>
            <td>Preceptor</td>
            <td><input name="preceptor"></td>
            </tr><tr>
            <td>Cantidad de Alumnos</td>
            <td><input name="cant_alumno"> </td>
            </tr><tr>
            <td>Turno</td>
            <td><input name="turno"></td>
            </tr><tr>
            <td>Curso</td>
            <td><input name="curso"> </td>
            </tr><tr>
            <td>Especialidad del curso</td>
            <td><input name="especiaidad_curso"></td>
            </tr><tr>
          <td >  
              <input type="reset"  value=" &#10006 "></td><td>
	   <input type="submit"  value=" Registrar "/></td>
        </tr> 
            
        </table>
        
        
        </form>
    
    </center>
    
    
    </body>
</html>