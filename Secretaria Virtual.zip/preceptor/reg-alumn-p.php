
<!DOCTYPE html>
<head>
<meta charset="utf-8">
    <title>Agregar Alumnos</title>
    <link rel="stylesheet" href="../css/estilo-prec.css">
<meta name="viewport" content="width=device-width, initial-scale=0.3,  maximum-scale=1">
</head>
<?php 
require_once 'header-prec.php';
?>
<div class="body5">
    
</div>

?>